// Import polyfills first for browser compatibility
import './polyfills';
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

// Note: StrictMode causes double renders in development to help detect side effects
// This is expected behavior and won't happen in production builds
// Our payment flow is protected against double execution with refs
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
