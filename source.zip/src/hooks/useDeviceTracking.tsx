
import { useEffect } from 'react';
import { UAParser } from 'ua-parser-js';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export function useDeviceTracking() {
  const { user, session } = useAuth();

  const trackDevice = async () => {
    if (!user || !session) return;

    try {
      const parser = new UAParser();
      const result = parser.getResult();
      
      // Get user's language
      const language = navigator.language || navigator.languages?.[0] || 'en';
      
      // Determine device type
      let deviceType = 'Desktop';
      if (result.device.type === 'mobile') deviceType = 'Mobile';
      else if (result.device.type === 'tablet') deviceType = 'Tablet';
      
      const deviceInfo = {
        user_id: user.id,
        os_name: result.os.name || 'Unknown',
        os_version: result.os.version || 'Unknown',
        browser_name: result.browser.name || 'Unknown',
        browser_version: result.browser.version || 'Unknown',
        device_type: deviceType,
        language: language,
        // IP address will be handled server-side if needed
      };

      console.log('Tracking device info:', deviceInfo);

      const { error } = await supabase
        .from('user_devices')
        .insert(deviceInfo);

      if (error) {
        console.error('Error tracking device:', error);
      } else {
        console.log('Device tracked successfully');
      }
    } catch (error) {
      console.error('Error in device tracking:', error);
    }
  };

  useEffect(() => {
    if (user && session) {
      // Track device on login/session start
      trackDevice();
    }
  }, [user, session]);

  return { trackDevice };
}
