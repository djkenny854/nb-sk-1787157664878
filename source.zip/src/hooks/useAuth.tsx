import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { getCurrentDomain } from '@/utils/domainConfig';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  userProfile: any;
  signUp: (email: string, password: string, username: string, phone: string) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<{ error: any }>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  updatePassword: (newPassword: string) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<any>(null);

  useEffect(() => {
    let mounted = true;

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;
        
        console.log('Auth state changed:', event, session?.user?.id);
        
        // Handle different auth events
        if (event === 'SIGNED_IN') {
          toast({
            title: "Welcome Back! 👋",
            description: "You have successfully signed in.",
          });
          
          // Redirect to app after successful sign in
          if (window.location.pathname === '/auth' || window.location.pathname === '/') {
            window.location.href = '/app';
          }
        } else if (event === 'SIGNED_OUT') {
          toast({
            title: "Signed Out",
            description: "You have been successfully signed out.",
          });
        } else if (event === 'TOKEN_REFRESHED') {
          console.log('Token refreshed');
        }
        
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Defer profile fetch to avoid blocking auth state change
          setTimeout(async () => {
            if (!mounted) return;
            try {
              // Check if profile exists
              let { data: profile, error } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', session.user.id)
                .single();

              if (error && error.code === 'PGRST116') {
                // Profile doesn't exist, create it
                console.log('Creating profile for user:', session.user.id);
                
                // Get profile picture from Google if available
                const avatarUrl = session.user.user_metadata?.avatar_url || 
                                session.user.user_metadata?.picture;
                
                const profileData = {
                  id: session.user.id,
                  email: session.user.email,
                  full_name: session.user.user_metadata?.full_name || 
                           session.user.user_metadata?.name ||
                           session.user.email?.split('@')[0],
                  avatar_url: avatarUrl,
                  created_at: new Date().toISOString(),
                  updated_at: new Date().toISOString()
                };

                const { data: newProfile, error: createError } = await supabase
                  .from('profiles')
                  .insert(profileData)
                  .select()
                  .single();

                if (createError) {
                  console.error('Error creating profile:', createError);
                } else {
                  profile = newProfile;
                  console.log('Profile created successfully');
                }
              } else if (error) {
                console.error('Error fetching profile:', error);
              } else if (profile) {
                // Update avatar if it's from Google and not already set
                const avatarUrl = session.user.user_metadata?.avatar_url || 
                                session.user.user_metadata?.picture;
                
                if (avatarUrl && !profile.avatar_url) {
                  console.log('Updating profile with Google avatar');
                  const { data: updatedProfile } = await supabase
                    .from('profiles')
                    .update({ 
                      avatar_url: avatarUrl,
                      updated_at: new Date().toISOString()
                    })
                    .eq('id', session.user.id)
                    .select()
                    .single();
                  
                  if (updatedProfile) {
                    profile = updatedProfile;
                  }
                }
              }
              
              if (mounted) {
                setUserProfile(profile);
              }
            } catch (error) {
              console.error('Error handling profile:', error);
            }
          }, 0);
        } else {
          setUserProfile(null);
        }
        
        if (mounted) {
          setLoading(false);
        }
      }
    );

    // Check for existing session
    const initializeAuth = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          console.error('Error getting session:', error);
        }
        if (mounted) {
          setSession(session);
          setUser(session?.user ?? null);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        if (mounted) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const isValidUgandanPhone = (phone: string): boolean => {
    const phoneRegex = /^\+256[0-9]{9}$/;
    return phoneRegex.test(phone);
  };

  const checkEmailExists = async (email: string): Promise<boolean> => {
    try {
      console.log('Checking if email exists:', email);
      
      // Check profiles table (covers both email/password and Google sign-ins)
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('email')
        .eq('email', email.toLowerCase())
        .maybeSingle();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Error checking email in profiles:', profileError);
        return false;
      }

      const emailExists = !!profileData;
      console.log('Email exists in profiles table:', emailExists);
      
      return emailExists;
    } catch (error) {
      console.error('Error checking email existence:', error);
      return false;
    }
  };

  const checkUserExists = async (email: string, username: string): Promise<{ emailExists: boolean; usernameExists: boolean }> => {
    try {
      console.log('Checking if user exists:', { email, username });
      
      // Check if email exists in profiles table
      const { data: emailData, error: emailError } = await supabase
        .from('profiles')
        .select('email')
        .eq('email', email.toLowerCase())
        .maybeSingle();

      if (emailError && emailError.code !== 'PGRST116') {
        console.error('Error checking email:', emailError);
      }

      // Check username in profiles table
      const { data: usernameData, error: usernameError } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('full_name', username)
        .maybeSingle();

      if (usernameError && usernameError.code !== 'PGRST116') {
        console.error('Error checking username:', usernameError);
      }

      const emailExists = !!emailData;
      const usernameExists = !!usernameData;
      
      console.log('User existence check results:', { emailExists, usernameExists });
      
      return {
        emailExists,
        usernameExists
      };
    } catch (error) {
      console.error('Error checking user existence:', error);
      return { emailExists: false, usernameExists: false };
    }
  };

  const signUp = async (email: string, password: string, username: string, phone: string) => {
    try {
      console.log('Attempting to sign up user:', { email, username, phone });
      
      // Validate email format
      if (!isValidEmail(email)) {
        toast({
          title: "Invalid Email",
          description: "Please enter a valid email address.",
          variant: "destructive"
        });
        return { error: { message: "Invalid email format" } };
      }

      // Validate phone number format
      if (!isValidUgandanPhone(phone)) {
        toast({
          title: "Invalid Phone Number",
          description: "Please enter a valid phone number (+256XXXXXXXXX).",
          variant: "destructive"
        });
        return { error: { message: "Invalid phone number format" } };
      }

      // Check if email or username exists in profiles
      const { emailExists, usernameExists } = await checkUserExists(email, username);
      
      if (emailExists) {
        toast({
          title: "Account Already Exists",
          description: "An account with this email already exists. If you signed up with Google, please use 'Sign in with Google' button.",
          variant: "destructive",
          duration: 6000,
        });
        return { error: { message: "Email already registered" } };
      }
      
      if (usernameExists) {
        toast({
          title: "Username Already Taken",
          description: "This username is already taken. Please choose another one.",
          variant: "destructive"
        });
        return { error: { message: "Username already taken" } };
      }

      const { data, error } = await supabase.auth.signUp({
        email: email.toLowerCase(),
        password,
        options: {
          data: {
            username: username,
            phone: phone,
            full_name: username
          },
          emailRedirectTo: `${window.location.origin}/app`
        }
      });

      if (error) {
        console.error('Signup error:', error);
        
        // Handle specific errors
        if (error.message.includes('User already registered')) {
          toast({
            title: "Account Already Exists",
            description: "This email is already registered. Please sign in instead.",
            variant: "destructive"
          });
        } else if (error.message.includes('email')) {
          toast({
            title: "Email Error",
            description: "There was an issue with the email. Please check and try again.",
            variant: "destructive"
          });
        } else {
          toast({
            title: "Registration Failed",
            description: error.message || "There was an error creating your account. Please try again.",
            variant: "destructive"
          });
        }
        return { error };
      }

      // If user was created, create/update the profile with phone number
      if (data.user) {
        try {
          console.log('Creating profile with phone number:', phone);
          
          // Use upsert to handle both create and update scenarios
          const { error: profileError } = await supabase
            .from('profiles')
            .upsert({
              id: data.user.id,
              email: email.toLowerCase(),
              full_name: username,
              phone: phone,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            }, {
              onConflict: 'id'
            });

          if (profileError) {
            console.error('Profile creation error:', profileError);
            // Don't block signup for profile errors, just log it
            console.log('Profile creation failed but signup succeeded');
          } else {
            console.log('Profile created successfully with phone:', phone);
          }
        } catch (profileErr) {
          console.error('Failed to create profile:', profileErr);
          // Don't block signup for profile errors
        }
      }

      // Check if email confirmation is required
      if (data.user && !data.session) {
        toast({
          title: "Account Created! 📧",
          description: "Please check your email to confirm your account before signing in.",
        });
      } else if (data.session) {
        // User is automatically signed in
        toast({
          title: "Account Created Successfully! 🎉",
          description: "Welcome to Kalaso Football Predictions! You can now subscribe to packages.",
        });
      }

      return { error: null };
    } catch (error: any) {
      console.error('Signup catch error:', error);
      toast({
        title: "Registration Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      console.log('Attempting to sign in user:', email);

      // Validate email format
      if (!isValidEmail(email)) {
        toast({
          title: "Invalid Email",
          description: "Please enter a valid email address.",
          variant: "destructive"
        });
        return { error: { message: "Invalid email format" } };
      }
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.toLowerCase(),
        password,
      });

      if (error) {
        console.error('Signin error:', error);
        
        // Handle specific errors
        if (error.message.includes('Invalid login credentials')) {
          toast({
            title: "Invalid Credentials",
            description: "The email or password you entered is incorrect.",
            variant: "destructive"
          });
        } else if (error.message.includes('Email not confirmed')) {
          toast({
            title: "Email Not Confirmed",
            description: "Please check your email and click the confirmation link before signing in.",
            variant: "destructive"
          });
        } else {
          toast({
            title: "Sign In Failed",
            description: error.message || "There was an error signing in. Please try again.",
            variant: "destructive"
          });
        }
        return { error };
      }

      // Success toast is handled by the auth state change listener
      return { error: null };
    } catch (error: any) {
      console.error('Signin catch error:', error);
      toast({
        title: "Sign In Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    }
  };

  const signOut = async () => {
    try {
      console.log('Attempting to sign out user...');
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        console.error('Signout error:', error);
        toast({
          title: "Sign Out Error",
          description: "There was an error signing out. Please try again.",
          variant: "destructive"
        });
      } else {
        // Clear local state immediately
        setUser(null);
        setSession(null);
        setUserProfile(null);
        console.log('Successfully signed out');
      }
      
      return { error };
    } catch (error: any) {
      console.error('Signout catch error:', error);
      toast({
        title: "Sign Out Error",
        description: "An unexpected error occurred while signing out.",
        variant: "destructive"
      });
      return { error };
    }
  };

  const resetPassword = async (email: string) => {
    try {
      // Validate email format
      if (!isValidEmail(email)) {
        toast({
          title: "Invalid Email",
          description: "Please enter a valid email address.",
          variant: "destructive"
        });
        return { error: { message: "Invalid email format" } };
      }

      // Check if email exists in database
      const emailExists = await checkEmailExists(email);
      
      if (!emailExists) {
        toast({
          title: "Email Not Found",
          description: "This email is not registered in our system. Please check the email or create a new account.",
          variant: "destructive"
        });
        return { error: { message: "Email not registered" } };
      }

      const currentDomain = getCurrentDomain();
      const redirectUrl = `${currentDomain}/reset-password`;

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl,
      });

      if (error) {
        console.error('Password reset error:', error);
        toast({
          title: "Reset Failed",
          description: error.message || "There was an error sending the reset email. Please try again.",
          variant: "destructive"
        });
        return { error };
      }

      toast({
        title: "Reset Email Sent! 📧",
        description: "Please check your email for password reset instructions.",
      });

      return { error: null };
    } catch (error: any) {
      console.error('Password reset catch error:', error);
      toast({
        title: "Reset Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    }
  };

  const updatePassword = async (newPassword: string) => {
    try {
      if (!user) {
        toast({
          title: "Not Authenticated",
          description: "You must be logged in to change your password.",
          variant: "destructive"
        });
        return { error: { message: "Not authenticated" } };
      }

      if (newPassword.length < 6) {
        toast({
          title: "Password Too Short",
          description: "Password must be at least 6 characters long.",
          variant: "destructive"
        });
        return { error: { message: "Password too short" } };
      }

      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) {
        console.error('Password update error:', error);
        toast({
          title: "Password Update Failed",
          description: error.message || "Failed to update password. Please try again.",
          variant: "destructive"
        });
        return { error };
      }

      toast({
        title: "Password Updated! 🎉",
        description: "Your password has been successfully updated.",
      });

      return { error: null };
    } catch (error: any) {
      console.error('Password update catch error:', error);
      toast({
        title: "Password Update Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
      return { error };
    }
  };

  const value = {
    user,
    session,
    loading,
    userProfile,
    signUp,
    signIn,
    signOut,
    resetPassword,
    updatePassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
