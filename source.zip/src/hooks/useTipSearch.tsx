import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface SearchResult {
  id: string;
  type: 'ticket' | 'package';
  title: string;
  subtitle?: string;
  status?: string;
}

export function useTipSearch() {
  const { user } = useAuth();
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const search = useCallback(async (query: string) => {
    if (!query.trim() || query.length < 2) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const searchResults: SearchResult[] = [];

      // Search packages
      const { data: packages } = await supabase
        .from('packages')
        .select('id, name, description, price_ugx')
        .ilike('name', `%${query}%`)
        .eq('status', 'active')
        .limit(5);

      if (packages) {
        packages.forEach(pkg => {
          searchResults.push({
            id: pkg.id,
            type: 'package',
            title: pkg.name,
            subtitle: `UGX ${pkg.price_ugx.toLocaleString()}`
          });
        });
      }

      // Search tickets by name
      const { data: tickets } = await supabase
        .from('tickets')
        .select('id, ticket_name, status, package_id, packages(name)')
        .ilike('ticket_name', `%${query}%`)
        .order('created_at', { ascending: false })
        .limit(10);

      if (tickets) {
        tickets.forEach(ticket => {
          searchResults.push({
            id: ticket.id,
            type: 'ticket',
            title: ticket.ticket_name,
            subtitle: (ticket.packages as any)?.name || 'Tip',
            status: ticket.status
          });
        });
      }

      setResults(searchResults);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults([]);
  }, []);

  return { results, isSearching, search, clearResults };
}
