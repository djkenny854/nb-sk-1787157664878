
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import {
  hasAccess,
  isInGracePeriod,
  getGraceDaysLeft,
  getAccessEndDate,
} from '@/lib/subscription';

interface Subscription {
  id: string;
  package_id: string;
  start_date: string;
  end_date: string;
  is_active: boolean;
  payment_reference: string;
  packages: {
    name: string;
    duration_days: number;
    grace_period_days: number;
  };
}


export function useSubscriptions() {
  const { user } = useAuth();
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchSubscriptions();
    const cleanup = setupRealtimeSubscription();
    return cleanup;
  }, [user]);

  const fetchSubscriptions = async () => {
    if (!user) return;

    try {
      console.log('🔍 Fetching subscriptions for user:', user.id);
      
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select(`
          *,
          packages (
            name,
            duration_days,
            grace_period_days
          )
        `)
        .eq('user_id', user.id)
        .eq('is_active', true)
        // Keep subscriptions that ended recently — grace period is applied below
        .gte('end_date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString())
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Error fetching subscriptions:', error);
        return;
      }

      // Only keep subscriptions still within their paid period OR grace period
      const accessible = ((data || []) as unknown as Subscription[]).filter((sub) =>
        hasAccess(sub)
      );

      console.log('✅ Fetched subscriptions (incl. grace):', accessible);
      setSubscriptions(accessible);

      
      // Check for expired subscriptions and send notifications
      await checkExpiredSubscriptions();
    } catch (error) {
      console.error('❌ Error fetching subscriptions:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkExpiredSubscriptions = async () => {
    if (!user) return;

    try {
      // Get recently expired subscriptions (within last 24 hours)
      const { data: expiredSubs, error } = await supabase
        .from('user_subscriptions')
        .select(`
          *,
          packages (name)
        `)
        .eq('user_id', user.id)
        .eq('is_active', true)
        .lt('end_date', new Date().toISOString())
        .gte('end_date', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

      if (error) {
        console.error('❌ Error checking expired subscriptions:', error);
        return;
      }

      // Send notifications for expired subscriptions
      if (expiredSubs && expiredSubs.length > 0) {
        for (const sub of expiredSubs) {
          await supabase
            .from('notifications')
            .insert({
              user_id: user.id,
              title: 'Subscription Expired',
              message: `Your ${sub.packages?.name || 'subscription'} has expired. Renew now to continue accessing premium tips!`,
              type: 'warning'
            });
        }
      }
    } catch (error) {
      console.error('❌ Error checking expired subscriptions:', error);
    }
  };

  const setupRealtimeSubscription = () => {
    if (!user) return;

    const channel = supabase
      .channel(`user-subscriptions-${user.id}-${Math.random().toString(36).slice(2)}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_subscriptions',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          console.log('🔄 Subscription data changed, refetching...');
          fetchSubscriptions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const getTimeRemaining = (endDate: string) => {
    const now = new Date();
    const end = new Date(endDate);
    const diffMs = end.getTime() - now.getTime();
    
    if (diffMs <= 0) return { days: 0, hours: 0, minutes: 0 };
    
    const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return { days, hours, minutes };
  };

  const getSubscriptionProgress = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const now = new Date();
    
    const totalDuration = end.getTime() - start.getTime();
    const elapsed = now.getTime() - start.getTime();
    const percentage = Math.max(0, Math.min(100, (elapsed / totalDuration) * 100));
    
    return percentage;
  };

  const hasActiveSubscription = (packageId: string) => {
    return subscriptions.some(sub => sub.package_id === packageId && hasAccess(sub));
  };

  const getActivePackageIds = () => {
    return subscriptions.filter(sub => hasAccess(sub)).map(sub => sub.package_id);
  };

  /** Subscriptions whose paid period ended but are still covered by grace */
  const graceSubscriptions = subscriptions.filter(sub => isInGracePeriod(sub));

  return {
    subscriptions,
    graceSubscriptions,
    loading,
    getTimeRemaining,
    getSubscriptionProgress,
    hasActiveSubscription,
    getActivePackageIds,
    isInGracePeriod,
    getGraceDaysLeft,
    getAccessEndDate,
    refetch: fetchSubscriptions
  };

}
