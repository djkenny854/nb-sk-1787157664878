
import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

export function useBannedAccountCheck() {
  const { user } = useAuth();
  const [isBanned, setIsBanned] = useState(false);
  const [showBannedModal, setShowBannedModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkBanStatus = async () => {
      if (!user?.id) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('is_banned')
          .eq('id', user.id)
          .maybeSingle();

        if (!error && data) {
          const banned = data.is_banned || false;
          setIsBanned(banned);
          if (banned) {
            setShowBannedModal(true);
          }
        }
      } catch (error) {
        console.error('Error checking ban status:', error);
      } finally {
        setLoading(false);
      }
    };

    checkBanStatus();
  }, [user]);

  return {
    isBanned,
    showBannedModal,
    setShowBannedModal,
    loading
  };
}
