
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { hasAccess } from '@/lib/subscription';

interface TipStats {
  totalTipsReceived: number;
  tipsFromSubscriptionStart: number;
  loading: boolean;
}

export function useSubscriptionTips() {
  const { user } = useAuth();
  const [tipStats, setTipStats] = useState<TipStats>({
    totalTipsReceived: 0,
    tipsFromSubscriptionStart: 0,
    loading: true
  });

  useEffect(() => {
    if (user) {
      fetchTipStats();
    }
  }, [user]);

  const fetchTipStats = async () => {
    if (!user) return;

    try {
      // Get the earliest subscription start date
      const { data: subscriptions, error: subError } = await supabase
        .from('user_subscriptions')
        .select('start_date')
        .eq('user_id', user.id)
        .order('start_date', { ascending: true });

      if (subError) {
        console.error('Error fetching subscriptions:', subError);
        setTipStats(prev => ({ ...prev, loading: false }));
        return;
      }

      const earliestSubscription = subscriptions?.[0];
      
      if (!earliestSubscription) {
        setTipStats({
          totalTipsReceived: 0,
          tipsFromSubscriptionStart: 0,
          loading: false
        });
        return;
      }

      // Get user's active package IDs
      const { data: activeSubscriptions, error: activeSubError } = await supabase
        .from('user_subscriptions')
        .select('package_id, end_date, is_active, packages(grace_period_days)')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .gte('end_date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString());

      if (activeSubError) {
        console.error('Error fetching active subscriptions:', activeSubError);
        setTipStats(prev => ({ ...prev, loading: false }));
        return;
      }

      const packageIds = (activeSubscriptions || []).filter((s: any) => hasAccess(s)).map((sub: any) => sub.package_id);

      if (packageIds.length === 0) {
        setTipStats({
          totalTipsReceived: 0,
          tipsFromSubscriptionStart: 0,
          loading: false
        });
        return;
      }

      // Count total tickets for subscribed packages
      const { count: totalCount, error: totalError } = await supabase
        .from('tickets')
        .select('*', { count: 'exact', head: true })
        .in('package_id', packageIds);

      // Count tickets from subscription start date
      const { count: fromSubscriptionCount, error: fromSubError } = await supabase
        .from('tickets')
        .select('*', { count: 'exact', head: true })
        .in('package_id', packageIds)
        .gte('created_at', earliestSubscription.start_date);

      if (totalError || fromSubError) {
        console.error('Error counting tickets:', totalError || fromSubError);
        setTipStats(prev => ({ ...prev, loading: false }));
        return;
      }

      setTipStats({
        totalTipsReceived: totalCount || 0,
        tipsFromSubscriptionStart: fromSubscriptionCount || 0,
        loading: false
      });

    } catch (error) {
      console.error('Error fetching tip stats:', error);
      setTipStats(prev => ({ ...prev, loading: false }));
    }
  };

  return { ...tipStats, refetch: fetchTipStats };
}
