
import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useNotifications } from '@/hooks/useNotifications';
import { useSubscriptions } from '@/hooks/useSubscriptions';

export function useLoginNotifications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { notifications, unreadCount } = useNotifications();
  const { subscriptions } = useSubscriptions();

  useEffect(() => {
    if (user) {
      checkLoginNotifications();
    }
  }, [user]);

  const checkLoginNotifications = async () => {
    if (!user) return;

    try {
      console.log('🔔 Checking login notifications for user:', user.id);

      // Check subscription expiry
      if (subscriptions.length > 0) {
        const nearExpiry = subscriptions.filter(sub => {
          const daysLeft = Math.ceil((new Date(sub.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
          return daysLeft <= 3 && daysLeft > 0;
        });

        nearExpiry.forEach(sub => {
          const daysLeft = Math.ceil((new Date(sub.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
          toast({
            title: "Subscription Expiring Soon",
            description: `Your ${sub.packages?.name} subscription expires in ${daysLeft} day${daysLeft === 1 ? '' : 's'}!`,
            variant: daysLeft <= 1 ? "destructive" : "default",
          });
        });
      }

      // Show unread notifications count
      if (unreadCount > 0) {
        toast({
          title: `${unreadCount} New Notification${unreadCount === 1 ? '' : 's'}`,
          description: "Check your notifications for important updates.",
        });
      }

      // Welcome back message
      toast({
        title: "Welcome back! 👋",
        description: "Check out the latest tips and updates in your dashboard.",
      });

    } catch (error) {
      console.error('💥 Error checking login notifications:', error);
    }
  };
}
