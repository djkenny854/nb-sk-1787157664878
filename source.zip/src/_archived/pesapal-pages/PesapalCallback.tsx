
import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export default function PesapalCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [processing, setProcessing] = useState(true);
  const [status, setStatus] = useState<string>('processing');
  const [message, setMessage] = useState<string>('Processing your payment with PesaPal...');

  useEffect(() => {
    const handleCallback = async () => {
      try {
        console.log('🔄 PesaPal callback received, processing...');
        
        const orderTrackingId = searchParams.get('OrderTrackingId');
        const orderMerchantReference = searchParams.get('OrderMerchantReference');
        
        console.log('📋 Callback parameters:', {
          orderTrackingId,
          orderMerchantReference,
          allParams: Object.fromEntries(searchParams.entries())
        });

        if (!orderTrackingId && !orderMerchantReference) {
          console.error('❌ Missing callback parameters');
          setStatus('error');
          setMessage('Invalid payment callback. Missing tracking information.');
          setTimeout(() => navigate('/payment-cancel'), 3000);
          return;
        }

        // Call the callback function
        const { data, error } = await supabase.functions.invoke('pesapal-callback', {
          body: {
            orderTrackingId,
            orderMerchantReference,
            allParams: Object.fromEntries(searchParams.entries())
          }
        });

        if (error) {
          console.error('❌ Callback function error:', error);
          setStatus('error');
          setMessage('Failed to process payment callback. Please contact support.');
          setTimeout(() => navigate('/payment-cancel'), 3000);
          return;
        }

        console.log('📊 Callback response:', data);

        if (data.status === 'completed') {
          setStatus('completed');
          setMessage('Payment successful! Your subscription is now active.');
          
          toast({
            title: "Payment Successful! 🎉",
            description: "Your subscription has been activated successfully.",
          });
          
          // Redirect to the main app instead of payment-success
          setTimeout(() => navigate('/app'), 2000);
        } else if (data.status === 'payment_success_db_error') {
          setStatus('pending');
          setMessage(data.message || 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.');
          
          toast({
            title: "Payment Successful",
            description: "We're verifying your subscription. Please wait a moment.",
          });
          
          setTimeout(() => navigate('/app?payment=verifying'), 5000);
        } else if (data.status === 'failed') {
          setStatus('failed');
          setMessage(data.message || 'Payment was not successful.');
          setTimeout(() => navigate('/payment-cancel'), 2000);
        } else {
          setStatus('pending');
          setMessage('Payment is being processed. Please wait...');
          setTimeout(() => navigate('/app?payment=pending'), 5000);
        }

      } catch (error) {
        console.error('💥 Callback processing error:', error);
        setStatus('error');
        setMessage('An error occurred while processing your payment. If you completed the payment, your subscription will be activated soon.');
        setTimeout(() => navigate('/app'), 5000);
      } finally {
        setProcessing(false);
      }
    };

    handleCallback();
  }, [searchParams, navigate]);

  const getStatusColor = () => {
    switch (status) {
      case 'completed':
        return 'text-green-400 bg-green-500/10 border-green-500/30';
      case 'failed':
      case 'error':
        return 'text-red-400 bg-red-500/10 border-red-500/30';
      case 'pending':
        return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
      default:
        return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'completed':
        return (
          <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        );
      case 'failed':
      case 'error':
        return (
          <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        );
      case 'pending':
        return (
          <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-xl border border-border p-8 max-w-md w-full text-center">
        {processing && (
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-6"></div>
        )}
        
        {!processing && (
          <div className="w-12 h-12 bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
            {getStatusIcon()}
          </div>
        )}
        
        <h1 className="text-xl font-bold text-foreground mb-4">
          {processing ? 'Processing Payment...' : 'Payment Update'}
        </h1>
        
        <p className="text-muted-foreground mb-6">
          {message}
        </p>

        <div className={`rounded-lg p-4 border ${getStatusColor()}`}>
          <p className="text-sm font-medium">
            {processing || status === 'pending' 
              ? 'Do not close this window. You will be redirected automatically.'
              : 'Redirecting you to the app now...'
            }
          </p>
        </div>

        {!processing && (
          <div className="mt-6 text-xs text-muted-foreground">
            <p>Having issues? Contact our support team for assistance.</p>
          </div>
        )}
      </div>
    </div>
  );
}
