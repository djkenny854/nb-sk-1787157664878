
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { Check, Sparkles } from 'lucide-react';

interface PackageType {
  id: string;
  name: string;
  description: string;
  duration_days: number;
  price_ugx: number;
  status: string;
}

export function FeaturedPackages() {
  const [packages, setPackages] = useState<PackageType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeaturedPackages();
  }, []);

  const fetchFeaturedPackages = async () => {
    setLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('packages')
        .select('*')
        .eq('status', 'active')
        .order('price_ugx', { ascending: true })
        .limit(3);

      if (!error && data) {
        setPackages(data);
      } else {
        console.error('Error fetching packages:', error);
      }
    } catch (error) {
      console.error('Error in fetchFeaturedPackages:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0
    }).format(price);
  };

  // Calculate a visual "original" price for marketing display only
  // The actual price charged is always the database price (price_ugx)
  const getDisplayOriginalPrice = (price: number) => {
    // Show a visual "was" price that's ~30% higher for marketing
    return Math.round(price * 1.3);
  };

  const getDisplaySavings = (price: number) => {
    const visualOriginal = getDisplayOriginalPrice(price);
    return visualOriginal - price;
  };

  if (loading) {
    return (
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-16">
            <Skeleton className="h-12 w-64 mx-auto mb-4" />
            <Skeleton className="h-6 w-96 mx-auto" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {Array.from({ length: 3 }).map((_, index) => (
              <Card key={index} className="relative overflow-hidden">
                <CardContent className="p-8">
                  <Skeleton className="h-6 w-24 mb-4" />
                  <Skeleton className="h-8 w-32 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-6" />
                  <Skeleton className="h-12 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-background relative overflow-hidden">      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Choose Your <span className="text-primary">Winning Package</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Select from our most popular subscription plans designed to maximize your betting success
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-6xl mx-auto">
          {packages.map((packageItem, index) => {
            const isRecommended = index === 0;
            // Visual prices for marketing display only - actual charge is always price_ugx
            const displayOriginalPrice = getDisplayOriginalPrice(packageItem.price_ugx);
            const displaySavings = getDisplaySavings(packageItem.price_ugx);
            
            return (
              <Card 
                key={packageItem.id} 
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
                  isRecommended ? 'border-2 border-primary shadow-md' : 'border border-border'
                }`}
              >
                <CardContent className="p-6">
                  {/* Recommended Badge */}
                  {isRecommended && (
                    <Badge className="mb-4 bg-primary text-primary-foreground border-0">
                      Recommended
                    </Badge>
                  )}
                  
                  {/* Package Name */}
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    {packageItem.name}
                  </h3>
                  
                  {/* Pricing - Shows actual database price */}
                  <div className="mb-2">
                    <span className="text-muted-foreground line-through text-base mr-2">
                      {formatPrice(displayOriginalPrice)}
                    </span>
                    <span className="text-3xl font-bold text-foreground">
                      {formatPrice(packageItem.price_ugx)}
                    </span>
                  </div>
                  
                  {/* Duration */}
                  <p className="text-sm text-muted-foreground mb-1">
                    {packageItem.duration_days} days access
                  </p>
                  
                  {/* Visual Savings Display - Marketing only */}
                  <p className="text-sm text-green-600 font-medium mb-2">
                    Save {formatPrice(displaySavings)} with this offer!
                  </p>
                  
                  {/* Price Info */}
                  <p className="text-sm text-muted-foreground mb-6">
                    One-time payment
                  </p>
                  
                  {/* CTA Button */}
                  <Link to="/auth" className="block mb-6">
                    <Button 
                      className={`w-full ${
                        isRecommended 
                          ? 'bg-primary text-primary-foreground hover:bg-primary/90' 
                          : 'bg-background text-primary border border-primary hover:bg-accent'
                      }`}
                      variant={isRecommended ? 'default' : 'outline'}
                    >
                      Get discount
                    </Button>
                  </Link>
                  
                  {/* Sharing Info */}
                  <p className="text-xs text-muted-foreground mb-6">
                    Share storage with up to five others
                  </p>
                  
                  {/* Features Icon */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="p-2 bg-primary/10 rounded">
                      <Sparkles className="h-4 w-4 text-primary" />
                    </div>
                    <p className="text-sm font-medium text-foreground pt-1">
                      Get access to new and powerful features
                    </p>
                  </div>
                  
                  {/* Features List */}
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Check className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground">
                        {packageItem.duration_days} days total access for premium betting tips
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground">
                        Expert match analysis with detailed insights
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground">
                        Daily premium tips with high success rate
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* See More Button */}
        <div className="text-center animate-fade-in-up">
          <Link to="/plans">
            <Button 
              size="lg" 
              variant="outline" 
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              View All Packages
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
