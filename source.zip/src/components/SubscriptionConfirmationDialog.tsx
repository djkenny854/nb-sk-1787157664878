import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Crown, Target, Users, Zap } from 'lucide-react';

interface Package {
  id: string;
  name: string;
  description: string;
  duration_days: number;
  price_ugx: number;
  status: string;
}

interface SubscriptionConfirmationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  packageItem: Package | null;
  isCurrentlySubscribed: boolean;
  onConfirm: () => void;
}

export function SubscriptionConfirmationDialog({ 
  open, 
  onOpenChange, 
  packageItem, 
  isCurrentlySubscribed,
  onConfirm 
}: SubscriptionConfirmationDialogProps) {
  if (!packageItem) return null;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0
    }).format(price);
  };

  const getPackageIcon = (name: string) => {
    if (name.toLowerCase().includes('premium')) return Crown;
    if (name.toLowerCase().includes('pro')) return Target;
    if (name.toLowerCase().includes('team')) return Users;
    return Zap;
  };

  const IconComponent = getPackageIcon(packageItem.name);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <IconComponent className="h-6 w-6 text-primary" />
            </div>
            Confirm Subscription
          </DialogTitle>
          <DialogDescription>
            {isCurrentlySubscribed 
              ? "You're about to extend your existing subscription"
              : "You're about to subscribe to this package"
            }
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Package Details */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-lg">{packageItem.name}</h3>
              {isCurrentlySubscribed && (
                <Badge variant="default" className="bg-green-100 text-green-800 text-xs">
                  Extension
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-muted-foreground">
              {packageItem.description}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>{packageItem.duration_days} days access</span>
              </div>
              <div className="text-xl font-bold text-primary">
                {formatPrice(packageItem.price_ugx)}
              </div>
            </div>
          </div>

          {/* Confirmation Message */}
          <div className="text-center py-2">
            <p className="text-sm text-muted-foreground">
              {isCurrentlySubscribed 
                ? `This will extend your current subscription by ${packageItem.duration_days} more days.`
                : `You will get ${packageItem.duration_days} days of premium access.`
              }
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              onClick={onConfirm}
              className="flex-1"
            >
              {isCurrentlySubscribed ? 'Extend Now' : 'Subscribe Now'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}