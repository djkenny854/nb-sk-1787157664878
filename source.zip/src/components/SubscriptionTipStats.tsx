
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Target, Calendar } from 'lucide-react';
import { useSubscriptionTips } from '@/hooks/useSubscriptionTips';

export function SubscriptionTipStats() {
  const { totalTipsReceived, tipsFromSubscriptionStart, loading } = useSubscriptionTips();

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-8 bg-muted rounded w-1/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300 flex items-center gap-2">
            <Target className="h-4 w-4" />
            Total Tips Received
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">
            {totalTipsReceived}
          </div>
          <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
            All time tips
          </p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-green-700 dark:text-green-300 flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Since Subscription
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-900 dark:text-green-100">
            {tipsFromSubscriptionStart}
          </div>
          <p className="text-xs text-green-600 dark:text-green-400 mt-1">
            Tips from first purchase
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
