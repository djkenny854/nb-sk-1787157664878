import { TipLoadingSkeleton } from './LoadingSkeleton';
import { useFreeTickets } from '@/hooks/useFreeTickets';
import { FileText, Gift } from 'lucide-react';
import { TipHorizontalCard } from './TipHorizontalCard';
import { PageTransition } from './PageTransition';
import { TopHeader } from './TopHeader';

export function FreeTipsSection() {
  const { freeTickets, loading, getStatusColor, getStatusIcon } = useFreeTickets();

  if (loading) {
    return (
      <PageTransition>
        <div className="min-h-screen bg-background">
          <TopHeader />
          <div className="p-4">
            <TipLoadingSkeleton />
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        {/* Top Header */}
        <TopHeader />

        {/* Banner */}
        <div className="px-4 py-3 border-b border-border bg-gradient-to-r from-blue-500/10 to-primary/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
              <Gift className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-xs text-foreground">Daily Free Predictions</h3>
              <p className="text-xs text-muted-foreground">Updated daily by our experts</p>
            </div>
          </div>
        </div>

        {/* Tips List - X.com style */}
        <div>
          {freeTickets.length > 0 ? (
            freeTickets.map((ticket) => (
              <TipHorizontalCard
                key={ticket.id}
                ticket={ticket}
                getStatusColor={getStatusColor}
                getStatusIcon={getStatusIcon}
                isFree={true}
              />
            ))
          ) : (
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
                <FileText className="w-6 h-6 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-sm text-foreground mb-1">No Free Tips Available</h3>
              <p className="text-xs text-muted-foreground max-w-xs mx-auto">
                Free tips will appear here when posted.
              </p>
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
