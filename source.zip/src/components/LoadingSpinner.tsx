import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'default' | 'dots' | 'pulse' | 'gradient' | 'google';
  className?: string;
  text?: string;
}

export function LoadingSpinner({ 
  size = 'md', 
  variant = 'google',
  className,
  text
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };

  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg'
  };

  if (variant === 'dots') {
    return (
      <div className={cn('flex flex-col items-center justify-center gap-3', className)}>
        <div className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className={cn(
                'rounded-full bg-gradient-to-r from-primary to-primary/60',
                size === 'sm' ? 'w-2 h-2' : size === 'md' ? 'w-2.5 h-2.5' : size === 'lg' ? 'w-3 h-3' : 'w-4 h-4'
              )}
              style={{
                animation: 'bounce 1.4s infinite ease-in-out both',
                animationDelay: `${i * 0.16}s`
              }}
            />
          ))}
        </div>
        {text && (
          <span className={cn('text-muted-foreground animate-pulse', textSizeClasses[size])}>
            {text}
          </span>
        )}
      </div>
    );
  }

  if (variant === 'pulse') {
    return (
      <div className={cn('flex flex-col items-center justify-center gap-3', className)}>
        <div className="relative">
          <div className={cn(
            'rounded-full bg-primary/30 animate-ping absolute inset-0',
            sizeClasses[size]
          )} />
          <div className={cn(
            'rounded-full bg-gradient-to-br from-primary to-primary/70 relative',
            sizeClasses[size]
          )} />
        </div>
        {text && (
          <span className={cn('text-muted-foreground animate-pulse', textSizeClasses[size])}>
            {text}
          </span>
        )}
      </div>
    );
  }

  if (variant === 'google' || variant === 'default' || variant === 'gradient') {
    return (
      <div className={cn('flex flex-col items-center justify-center gap-3', className)}>
        <div className={cn('google-spinner', sizeClasses[size])} aria-hidden="true">
          <svg className="google-spinner-svg" viewBox="0 0 50 50">
            <circle className="google-spinner-path" cx="25" cy="25" r="20" fill="none" strokeWidth="4" />
          </svg>
        </div>
        {text && (
          <span className={cn('text-muted-foreground font-medium', textSizeClasses[size])}>
            {text}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={cn('flex flex-col items-center justify-center gap-3', className)}>
      <div className="relative">
        {/* Outer glow ring */}
        <div 
          className={cn(
            'absolute inset-0 rounded-full blur-sm opacity-50',
            sizeClasses[size]
          )}
          style={{
            background: 'conic-gradient(from 0deg, transparent, hsl(var(--primary)), transparent)'
          }}
        />
        
        {/* Main spinner */}
        <div 
          className={cn(
            'rounded-full border-2 border-transparent relative',
            sizeClasses[size]
          )}
          style={{
            background: `
              linear-gradient(hsl(var(--background)), hsl(var(--background))) padding-box,
              conic-gradient(
                from 0deg,
                hsl(var(--primary)) 0deg,
                hsl(var(--primary) / 0.8) 90deg,
                hsl(var(--primary) / 0.4) 180deg,
                transparent 270deg,
                hsl(var(--primary)) 360deg
              ) border-box
            `,
            animation: 'spin 1s linear infinite'
          }}
        >
          {/* Inner glow */}
          <div 
            className="absolute inset-1 rounded-full"
            style={{
              background: 'radial-gradient(circle, hsl(var(--primary) / 0.1) 0%, transparent 70%)'
            }}
          />
        </div>

        {/* Center dot */}
        <div 
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary animate-pulse"
          style={{
            width: size === 'sm' ? '4px' : size === 'md' ? '6px' : size === 'lg' ? '8px' : '10px',
            height: size === 'sm' ? '4px' : size === 'md' ? '6px' : size === 'lg' ? '8px' : '10px'
          }}
        />
      </div>
      
      {text && (
        <span className={cn('text-muted-foreground font-medium', textSizeClasses[size])}>
          {text}
        </span>
      )}
    </div>
  );
}

// Full page loading overlay
export function FullPageLoader({ text = 'Loading...' }: { text?: string }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <LoadingSpinner size="xl" variant="google" text={text} />
    </div>
  );
}

// Button loading spinner (inline)
export function ButtonSpinner({ className }: { className?: string }) {
  return (
    <LoadingSpinner size="sm" variant="google" className={cn('gap-0', className)} />
  );
}
