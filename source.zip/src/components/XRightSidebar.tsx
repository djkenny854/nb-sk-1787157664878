import { Search, TrendingUp, Trophy, Flame, Target, Zap } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useNavigate } from 'react-router-dom'
import { useTickets } from '@/hooks/useTickets'
import { useSubscriptions } from '@/hooks/useSubscriptions'
import { usePackageStats } from '@/hooks/usePackageStats'
import { useTipSearch } from '@/hooks/useTipSearch'
import { TicketHeatMap } from '@/components/TicketHeatMap'
import { useState, useEffect } from 'react'

export function XRightSidebar() {
  const navigate = useNavigate()
  const { tickets } = useTickets()
  const { subscriptions } = useSubscriptions()
  const { packageStats, loading: statsLoading } = usePackageStats()
  const { results, isSearching, search, clearResults } = useTipSearch()
  const [searchQuery, setSearchQuery] = useState('')
  const [stats, setStats] = useState({
    weeklyAccuracy: 0,
    totalTips: 0,
    wonTips: 0,
  })

  // Calculate stats
  useEffect(() => {
    if (tickets.length > 0) {
      const wonTickets = tickets.filter(t => t.status === 'won').length
      const lostTickets = tickets.filter(t => t.status === 'lost').length
      const totalCompleted = wonTickets + lostTickets
      const accuracy = totalCompleted > 0 ? (wonTickets / totalCompleted) * 100 : 0

      setStats({
        weeklyAccuracy: accuracy,
        totalTips: tickets.length,
        wonTips: wonTickets,
      })
    }
  }, [tickets])

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery) {
        search(searchQuery);
      } else {
        clearResults();
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, search, clearResults]);

  const handleResultClick = (result: typeof results[0]) => {
    if (result.type === 'package') {
      navigate('/app/packages');
    } else {
      navigate('/app/tips');
    }
    setSearchQuery('');
    clearResults();
  };

  // Generate hot tips news based on package stats
  const hotTipsNews = packageStats
    .filter(pkg => pkg.winStreak >= 2 || pkg.accuracy >= 70)
    .slice(0, 5)
    .map(pkg => {
      if (pkg.winStreak >= 5) {
        return {
          icon: Flame,
          iconColor: 'text-orange-500',
          category: '🔥 Hot Streak',
          title: `${pkg.packageName} on fire!`,
          subtitle: `${pkg.winStreak} wins in a row`,
          highlight: true
        };
      } else if (pkg.winStreak >= 3) {
        return {
          icon: Trophy,
          iconColor: 'text-yellow-500',
          category: '🏆 Winning',
          title: `${pkg.packageName}`,
          subtitle: `${pkg.winStreak} consecutive wins`,
          highlight: false
        };
      } else if (pkg.accuracy >= 80) {
        return {
          icon: Target,
          iconColor: 'text-green-500',
          category: '🎯 High Accuracy',
          title: `${pkg.packageName}`,
          subtitle: `${pkg.accuracy.toFixed(0)}% win rate`,
          highlight: false
        };
      } else {
        return {
          icon: TrendingUp,
          iconColor: 'text-blue-500',
          category: '📈 Trending',
          title: `${pkg.packageName}`,
          subtitle: `${pkg.recentWins} wins this week`,
          highlight: false
        };
      }
    });

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="sticky top-0 pt-1 pb-3 bg-background z-10">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            type="text"
            placeholder="Search tips, packages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-[42px] pl-12 pr-4 bg-muted/50 border-0 rounded-full text-[15px] placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-primary focus-visible:bg-background"
          />
        </div>

        {/* Search Results */}
        {(results.length > 0 || isSearching) && searchQuery && (
          <div className="mt-2 bg-background border border-border rounded-xl shadow-lg overflow-hidden max-h-60 overflow-y-auto">
            {isSearching ? (
              <div className="p-3 text-center text-sm text-muted-foreground">
                Searching...
              </div>
            ) : (
              results.map((result) => (
                <button
                  key={`${result.type}-${result.id}`}
                  onClick={() => handleResultClick(result)}
                  className="w-full px-3 py-2 flex items-center gap-2 hover:bg-muted/50 transition-colors text-left"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {result.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {result.subtitle}
                    </p>
                  </div>
                </button>
              ))
            )}
          </div>
        )}
      </div>

      {/* Heat Map */}
      <TicketHeatMap />

      {/* Subscribe to Premium Card */}
      <Card className="bg-background border border-border rounded-2xl overflow-hidden">
        <CardContent className="p-4">
          <h2 className="text-lg font-extrabold text-foreground mb-2">
            Subscribe to Premium
          </h2>
          <p className="text-sm text-muted-foreground mb-3">
            Get access to expert tips and increase your winning chances.
          </p>
          <Button 
            onClick={() => navigate('/app/packages')}
            className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full font-bold px-5"
          >
            Subscribe
          </Button>
        </CardContent>
      </Card>

      {/* Hot Tips News - Real Package Stats */}
      <Card className="bg-background border border-border rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <h2 className="text-lg font-extrabold text-foreground px-4 pt-3 pb-2 flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Package Highlights
          </h2>
          
          {statsLoading ? (
            <div className="px-4 py-6 text-center">
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-muted rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-muted rounded w-1/2 mx-auto"></div>
              </div>
            </div>
          ) : hotTipsNews.length > 0 ? (
            hotTipsNews.map((news, index) => (
              <div 
                key={index}
                onClick={() => navigate('/app/packages')}
                className={`px-4 py-3 hover:bg-muted/50 transition-colors cursor-pointer border-t border-border first:border-t-0 ${news.highlight ? 'bg-orange-500/5' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 ${news.iconColor}`}>
                    <news.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs text-muted-foreground">{news.category}</span>
                    <h3 className="font-bold text-sm text-foreground">{news.title}</h3>
                    <span className="text-xs text-muted-foreground">{news.subtitle}</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="px-4 py-6 text-center">
              <p className="text-sm text-muted-foreground">No highlights yet</p>
              <p className="text-xs text-muted-foreground mt-1">Package stats will appear here</p>
            </div>
          )}

          {hotTipsNews.length > 0 && (
            <button 
              onClick={() => navigate('/app/packages')}
              className="w-full px-4 py-3 text-left text-primary hover:bg-muted/50 transition-colors text-sm border-t border-border"
            >
              View all packages
            </button>
          )}
        </CardContent>
      </Card>

      {/* Performance Stats Card */}
      <Card className="bg-background border border-border rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <h2 className="text-lg font-extrabold text-foreground px-4 pt-3 pb-2">
            Your Performance
          </h2>
          
          <div className="px-4 py-3 border-t border-border">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Win Rate</span>
              <span className="text-sm font-bold text-foreground">{stats.weeklyAccuracy.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Total Tips</span>
              <span className="text-sm font-bold text-foreground">{stats.totalTips}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Won Tips</span>
              <span className="text-sm font-bold text-green-500">{stats.wonTips}</span>
            </div>
          </div>

          {subscriptions.length > 0 && (
            <div className="px-4 py-3 border-t border-border">
              <span className="text-xs text-muted-foreground">Active Packages</span>
              <div className="mt-1 flex flex-wrap gap-1">
                {subscriptions.map((sub, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full"
                  >
                    {sub.packages?.name || `Package ${index + 1}`}
                  </span>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Footer Links */}
      <div className="px-4 pb-4">
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <a href="/terms" className="hover:underline">Terms of Service</a>
          <a href="/terms" className="hover:underline">Privacy Policy</a>
          <a href="/help" className="hover:underline">Help Center</a>
          <a href="/contact" className="hover:underline">Contact</a>
        </div>
        <p className="text-xs text-muted-foreground mt-2">© 2024 Kalaso Football Predictions</p>
      </div>
    </div>
  )
}
