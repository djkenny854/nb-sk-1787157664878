
import { Star, User, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const testimonials = [
  {
    id: 1,
    name: "John Mukasa",
    location: "Kampala",
    rating: 5,
    comment: "Kalaso Football Predictions has completely changed my betting experience. Their predictions are incredibly accurate and I've been winning consistently for the past 3 months!",
    winnings: "UGX 2,500,000"
  },
  {
    id: 2,
    name: "Sarah Namazzi",
    location: "Entebbe",
    rating: 5,
    comment: "I was skeptical at first, but after winning my first bet with their premium tips, I became a believer. The analysis is top-notch!",
    winnings: "UGX 1,800,000"
  },
  {
    id: 3,
    name: "David Okello",
    location: "Jinja",
    rating: 5,
    comment: "Best investment I've ever made! The VIP package has given me insider knowledge that consistently delivers profits.",
    winnings: "UGX 3,200,000"
  },
  {
    id: 4,
    name: "Grace Namukasa",
    location: "Mbarara",
    rating: 5,
    comment: "Professional service with real results. I've recommended Kalaso Football Predictions to all my friends. The customer support is excellent too!",
    winnings: "UGX 1,500,000"
  },
  {
    id: 5,
    name: "Moses Kiwanuka",
    location: "Gulu",
    rating: 5,
    comment: "From losing streaks to consistent wins - that's my story with Kalaso Football Predictions. Their tips are backed by solid research.",
    winnings: "UGX 2,100,000"
  },
  {
    id: 6,
    name: "Mary Akello",
    location: "Fort Portal",
    rating: 5,
    comment: "Amazing service! The daily tips have helped me build a steady income stream. I can't imagine betting without their guidance now.",
    winnings: "UGX 1,900,000"
  }
];

export default function TestimonialsSection() {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < rating ? 'text-blue-500 fill-blue-500' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="py-20 bg-gradient-to-br from-gray-50 to-blue-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 font-heading animate-fade-in">
            What Our <span className="gradient-text">Winners</span> Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto animate-fade-in">
            Join thousands of satisfied customers who have transformed their betting experience with Kalaso Football Predictions. 
            Here's what they have to say about their success stories.
          </p>
        </div>

        {/* Horizontal Scrolling Container */}
        <div className="relative">
          <div className="flex gap-6 overflow-x-auto pb-6 scrollbar-hide snap-x snap-mandatory scroll-smooth" 
               style={{
                 scrollbarWidth: 'none',
                 msOverflowStyle: 'none',
               }}>
            <style>{`
              .scrollbar-hide::-webkit-scrollbar {
                display: none;
              }
            `}</style>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className="flex-none w-[350px] md:w-[400px] snap-center"
                style={{
                  animation: 'slideInRight 0.5s ease-out',
                  animationDelay: `${index * 150}ms`,
                  animationFillMode: 'both'
                }}
              >
                <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-8 hover:shadow-2xl transition-all duration-500 relative overflow-hidden h-full hover:-translate-y-2 transform">
                  {/* Background decoration with animation */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-blue-100 to-purple-100 rounded-bl-full opacity-50 animate-pulse"></div>
                  
                  <div className="relative">
                    {/* Header */}
                    <div className="flex items-center space-x-4 mb-6">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <User className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 text-xl font-heading">{testimonial.name}</h4>
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {testimonial.location}
                        </p>
                      </div>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center space-x-1 mb-5">
                      {renderStars(testimonial.rating)}
                    </div>

                    {/* Comment */}
                    <blockquote className="text-gray-700 mb-6 leading-relaxed italic text-base min-h-[100px]">
                      "{testimonial.comment}"
                    </blockquote>

                    {/* Winnings */}
                    <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-5 border-2 border-green-200 shadow-md">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-2 font-medium">Total Winnings</p>
                        <p className="text-3xl font-bold gradient-text">{testimonial.winnings}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Scroll Indicators */}
          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <div key={index} className="w-2 h-2 rounded-full bg-gray-300 hover:bg-blue-500 transition-colors cursor-pointer"></div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-3xl shadow-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4 font-heading">
              Ready to Join Our Winners Circle?
            </h3>
            <p className="text-gray-600 mb-6">
              Don't just take their word for it. Start your own winning journey today with our expert predictions and professional analysis.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/plans">
                <button className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-2xl font-bold transition-all duration-300 hover:shadow-lg">
                  View Packages
                </button>
              </Link>
              <Link to="/free-tips">
                <button className="w-full sm:w-auto border-2 border-gray-300 text-gray-700 hover:bg-gray-50 px-8 py-3 rounded-2xl font-bold transition-all duration-300">
                  See Free Tips
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
