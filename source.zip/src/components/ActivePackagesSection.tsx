import { useSubscriptions } from '@/hooks/useSubscriptions';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Trophy, ChevronRight, Clock, AlertTriangle } from 'lucide-react';
import { isInGracePeriod, getGraceDaysLeft } from '@/lib/subscription';
import { useNavigate } from 'react-router-dom';

interface AnimatedCircularProgressProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  isExpiring?: boolean;
}

function AnimatedCircularProgress({ 
  percentage, 
  size = 52, 
  strokeWidth = 4,
  isExpiring = false 
}: AnimatedCircularProgressProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const remaining = 100 - percentage;
  const strokeDashoffset = circumference - (remaining / 100) * circumference;
  
  const getGradientId = (idx: number) => isExpiring ? `expiring-gradient-${idx}` : `active-gradient-${idx}`;
  const uniqueId = Math.random().toString(36).substr(2, 9);
  
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" style={{ width: size, height: size }}>
        <defs>
          <linearGradient id={`active-gradient-${uniqueId}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--primary))" />
            <stop offset="50%" stopColor="hsl(217 91% 60%)" />
            <stop offset="100%" stopColor="hsl(142 76% 36%)" />
          </linearGradient>
          <linearGradient id={`expiring-gradient-${uniqueId}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(38 92% 50%)" />
            <stop offset="100%" stopColor="hsl(0 84% 60%)" />
          </linearGradient>
        </defs>
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--muted))"
          strokeWidth={strokeWidth}
          fill="transparent"
          className="opacity-30"
        />
        {/* Progress circle */}
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={`url(#${isExpiring ? `expiring-gradient-${uniqueId}` : `active-gradient-${uniqueId}`})`}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={cn(
          "text-[10px] font-bold",
          isExpiring ? "text-orange-400" : "text-primary"
        )}>
          {remaining.toFixed(0)}%
        </span>
      </div>
    </div>
  );
}

export function ActivePackagesSection() {
  const { subscriptions, loading, getTimeRemaining, getSubscriptionProgress } = useSubscriptions();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="px-4 py-3 border-b border-border bg-muted/10">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-5 h-5 rounded-full bg-muted animate-pulse" />
          <div className="h-3 w-32 bg-muted rounded animate-pulse" />
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-hide">
          {[1, 2].map((i) => (
            <div key={i} className="w-36 h-20 bg-muted/30 rounded-xl animate-pulse flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <div className="px-4 py-3 border-b border-border bg-muted/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-muted/50 flex items-center justify-center">
              <Trophy className="w-3 h-3 text-muted-foreground" />
            </div>
            <span className="text-xs text-muted-foreground">No active packages</span>
          </div>
          <button 
            onClick={() => navigate('/app/packages')}
            className="text-xs text-primary font-medium hover:underline flex items-center gap-0.5"
          >
            Subscribe <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-3 border-b border-border bg-muted/5">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-primary to-green-500 flex items-center justify-center">
            <Trophy className="w-3 h-3 text-white" />
          </div>
          <span className="font-semibold text-xs text-foreground">Active Packages</span>
        </div>
        <button 
          onClick={() => navigate('/app/packages')}
          className="text-xs text-primary font-medium hover:underline flex items-center gap-0.5"
        >
          View all <ChevronRight className="w-3 h-3" />
        </button>
      </div>
      
      {/* Horizontal scroll container */}
      <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-hide -mx-1 px-1">
        {subscriptions.map((subscription, index) => {
          const timeRemaining = getTimeRemaining(subscription.end_date);
          const progress = getSubscriptionProgress(subscription.start_date, subscription.end_date);
          const inGrace = isInGracePeriod(subscription as any);
          const graceDaysLeft = getGraceDaysLeft(subscription as any);
          const isExpiring = inGrace || timeRemaining.days <= 3;

          return (
            <motion.div 
              key={subscription.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "flex-shrink-0 rounded-xl p-3 border transition-all cursor-pointer hover:shadow-md min-w-[140px]",
                isExpiring 
                  ? "bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/30" 
                  : "bg-gradient-to-br from-primary/10 via-blue-500/5 to-green-500/10 border-primary/20"
              )}
              onClick={() => navigate('/app/packages')}
            >
              <div className="flex items-center gap-2.5">
                <AnimatedCircularProgress 
                  percentage={progress} 
                  isExpiring={isExpiring}
                  size={44}
                  strokeWidth={3}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-xs text-foreground truncate">
                    {subscription.packages?.name || 'Package'}
                  </p>
                  <div className="flex items-center gap-1 mt-0.5">
                    {inGrace ? (
                      <>
                        <AlertTriangle className="w-2.5 h-2.5 text-orange-400" />
                        <span className="text-[10px] font-medium text-orange-400">
                          Grace: {graceDaysLeft}d left
                        </span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-2.5 h-2.5 text-muted-foreground" />
                        <span className={cn(
                          "text-[10px] font-medium",
                          isExpiring ? "text-orange-400" : "text-muted-foreground"
                        )}>
                          {timeRemaining.days}d {timeRemaining.hours}h
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
