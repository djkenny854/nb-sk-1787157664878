import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { TipLoadingSkeleton } from './LoadingSkeleton';
import { useTickets } from '@/hooks/useTickets';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { FileText, Lock, History, Zap, Flame } from 'lucide-react';
import { useEffect } from 'react';
import { TipHorizontalCard } from './TipHorizontalCard';
import { useNavigate } from 'react-router-dom';
import { PageTransition } from './PageTransition';
import { TopHeader } from './TopHeader';
import { ActivePackagesSection } from './ActivePackagesSection';

export function EnhancedTipsTab() {
  const { tickets, loading, getStatusColor, getStatusIcon } = useTickets();
  const { subscriptions } = useSubscriptions();
  const navigate = useNavigate();

  // Prevent screenshots
  useEffect(() => {
    const preventScreenshot = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey && e.shiftKey && e.key === 'S') ||
        (e.key === 'PrintScreen') ||
        (e.metaKey && e.shiftKey && e.key === '4') ||
        (e.metaKey && e.shiftKey && e.key === '3')
      ) {
        e.preventDefault();
        return false;
      }
    };

    const preventRightClick = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };

    document.addEventListener('keydown', preventScreenshot);
    document.addEventListener('contextmenu', preventRightClick);

    return () => {
      document.removeEventListener('keydown', preventScreenshot);
      document.removeEventListener('contextmenu', preventRightClick);
    };
  }, []);

  const groupTicketsByDate = (tickets: any[]) => {
    const today = new Date();
    const oneDayAgo = new Date(today.getTime() - (24 * 60 * 60 * 1000));
    
    const recent = tickets.filter(ticket => {
      const ticketDate = new Date(ticket.created_at);
      return ticketDate >= oneDayAgo;
    });
    
    const history = tickets.filter(ticket => {
      const ticketDate = new Date(ticket.created_at);
      return ticketDate < oneDayAgo;
    });

    return { recent, history };
  };

  if (loading) {
    return (
      <PageTransition>
        <div className="min-h-screen bg-background">
          <TopHeader />
          <div className="p-4">
            <TipLoadingSkeleton />
          </div>
        </div>
      </PageTransition>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <PageTransition>
        <div className="min-h-screen bg-background">
          <TopHeader />
          
          <div className="p-4">
            <div className="text-center py-8">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Lock className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-base font-bold text-foreground mb-1">No Active Subscription</h2>
              <p className="text-xs text-muted-foreground mb-4 max-w-sm mx-auto">
                Subscribe to unlock premium tips and start winning!
              </p>
              <Button 
                onClick={() => navigate('/app/packages')}
                className="rounded-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-5 text-sm"
                size="sm"
              >
                View Packages
              </Button>
            </div>
          </div>
        </div>
      </PageTransition>
    );
  }

  const { recent, history } = groupTicketsByDate(tickets);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background select-none" style={{ userSelect: 'none', WebkitUserSelect: 'none' }}>
        {/* Top Header */}
        <TopHeader />

        {/* Active Packages Section with Circular Progress */}
        <ActivePackagesSection />

        {/* X.com Style Tabs Navigation */}
        <Tabs defaultValue="recent" className="w-full">
          <div className="border-b border-border sticky top-14 z-10 bg-background">
            <TabsList className="w-full h-auto bg-transparent border-0 p-0 grid grid-cols-2">
              <TabsTrigger 
                value="recent" 
                className="h-12 rounded-none border-0 bg-transparent data-[state=active]:bg-transparent data-[state=active]:shadow-none font-semibold text-sm text-muted-foreground data-[state=active]:text-foreground relative group"
              >
                <span className="flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  Today's Tips
                </span>
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-1 bg-primary rounded-full scale-x-0 group-data-[state=active]:scale-x-100 transition-transform" />
              </TabsTrigger>
              <TabsTrigger 
                value="history" 
                className="h-12 rounded-none border-0 bg-transparent data-[state=active]:bg-transparent data-[state=active]:shadow-none font-semibold text-sm text-muted-foreground data-[state=active]:text-foreground relative group"
              >
                <span className="flex items-center gap-2">
                  <History className="w-4 h-4" />
                  History
                </span>
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-1 bg-primary rounded-full scale-x-0 group-data-[state=active]:scale-x-100 transition-transform" />
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="recent" className="mt-0">
            {/* Tips List - X.com style */}
            <div>
              {recent.length > 0 ? (
                recent.map((ticket) => (
                  <TipHorizontalCard
                    key={ticket.id}
                    ticket={ticket}
                    getStatusColor={getStatusColor}
                    getStatusIcon={getStatusIcon}
                    isFree={false}
                  />
                ))
              ) : (
                <div className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold text-sm text-foreground mb-1">No Recent Tips</h3>
                  <p className="text-xs text-muted-foreground max-w-xs mx-auto">
                    New tips will appear here when posted.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="history" className="mt-0">
            <div>
              {history.length > 0 ? (
                history.map((ticket) => (
                  <TipHorizontalCard
                    key={ticket.id}
                    ticket={ticket}
                    getStatusColor={getStatusColor}
                    getStatusIcon={getStatusIcon}
                    isFree={false}
                  />
                ))
              ) : (
                <div className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-3">
                    <History className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold text-sm text-foreground mb-1">No History Yet</h3>
                  <p className="text-xs text-muted-foreground max-w-xs mx-auto">
                    Tips older than 24 hours will appear here.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  );
}
