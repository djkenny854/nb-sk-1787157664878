import { useEffect } from 'react';
import { Routes, Route, useNavigate, Navigate, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { useBannedAccountCheck } from '@/hooks/useBannedAccountCheck';
import { useWinCelebration } from '@/hooks/useWinCelebration';
import { useUnseenWins } from '@/hooks/useUnseenWins';
import { XStyleLayout } from '@/components/XStyleLayout';
import { BannedAccountScreen } from '@/components/BannedAccountScreen';
import { FullPageLoader } from '@/components/LoadingSpinner';
import Dashboard from './Dashboard';
import { EnhancedTipsTab } from '@/components/EnhancedTipsTab';
import { FreeTipsSection } from '@/components/FreeTipsSection';
import { PackagesTab } from '@/components/PackagesTab';
import Transactions from './Transactions';
import ProfileTab from '@/components/ProfileTab';
import Notifications from './Notifications';

export default function Index() {
  const { user, loading: authLoading } = useAuth();
  const { isBanned, loading: banCheckLoading } = useBannedAccountCheck();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Initialize win celebration - triggers confetti when tips are marked as won
  useWinCelebration();
  
  // Check for unseen wins when user returns to the app
  useUnseenWins();

  useEffect(() => {
    if (authLoading) {
      console.log('Auth loading, delaying navigation...');
      return;
    }
    if (!user) {
      console.log('No user found after auth loaded, redirecting to /auth');
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  // Show loading while auth is initializing
  if (authLoading) {
    return <FullPageLoader text="Loading..." />;
  }

  // Show loading while checking ban status
  if (banCheckLoading) {
    return <FullPageLoader text="Checking account..." />;
  }

  // Show banned screen if account is banned
  if (isBanned) {
    return <BannedAccountScreen />;
  }

  if (!user) {
    return null;
  }

  return (
    <XStyleLayout>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/tips" element={<EnhancedTipsTab />} />
          <Route path="/free-tips" element={<FreeTipsSection />} />
          <Route path="/packages" element={<PackagesTab />} />
          <Route path="/transactions" element={<Transactions />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/profile" element={<ProfileTab />} />
          <Route path="*" element={<Navigate to="/app" replace />} />
        </Routes>
      </AnimatePresence>
    </XStyleLayout>
  );
}
