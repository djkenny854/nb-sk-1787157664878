/**
 * Grace period helpers.
 *
 * Each package defines `grace_period_days`. When a subscription's `end_date`
 * passes, the user keeps access for that many extra days so they can renew
 * without losing their tickets.
 */

const DAY_MS = 24 * 60 * 60 * 1000;

export interface GraceAware {
  end_date: string;
  is_active?: boolean;
  packages?: { grace_period_days?: number | null } | null;
}

export function getGraceDays(sub: GraceAware): number {
  return sub.packages?.grace_period_days ?? 0;
}

/** Final moment (inclusive of grace) that the subscription still grants access. */
export function getAccessEndDate(sub: GraceAware): Date {
  return new Date(new Date(sub.end_date).getTime() + getGraceDays(sub) * DAY_MS);
}

/** True while the paid period OR the grace period is still running. */
export function hasAccess(sub: GraceAware, now: Date = new Date()): boolean {
  if (sub.is_active === false) return false;
  return getAccessEndDate(sub).getTime() > now.getTime();
}

/** True only when the paid period has ended but grace still covers the user. */
export function isInGracePeriod(sub: GraceAware, now: Date = new Date()): boolean {
  const end = new Date(sub.end_date).getTime();
  return now.getTime() >= end && hasAccess(sub, now);
}

/** Whole days (rounded up) of grace left. 0 when not in grace. */
export function getGraceDaysLeft(sub: GraceAware, now: Date = new Date()): number {
  if (!isInGracePeriod(sub, now)) return 0;
  return Math.max(
    0,
    Math.ceil((getAccessEndDate(sub).getTime() - now.getTime()) / DAY_MS)
  );
}
