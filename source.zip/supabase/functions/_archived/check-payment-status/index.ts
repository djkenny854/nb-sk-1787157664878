
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { orderTrackingId } = await req.json()
    
    if (!orderTrackingId) {
      throw new Error('Missing orderTrackingId')
    }

    console.log('🔍 Checking payment status for:', orderTrackingId)

    // Use the new database function to find the transaction
    const { data: transactionData, error: transactionError } = await supabaseClient
      .rpc('find_pesapal_transaction', {
        p_order_tracking_id: orderTrackingId
      })

    if (transactionError || !transactionData || transactionData.length === 0) {
      console.error('❌ Transaction not found:', transactionError)
      return new Response(
        JSON.stringify({ 
          success: false,
          status: 'not_found',
          message: 'Transaction not found'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    const transaction = transactionData[0]
    console.log('📋 Found transaction:', transaction)

    // If already completed, return success
    if (transaction.status === 'completed') {
      return new Response(
        JSON.stringify({ 
          success: true,
          status: 'completed',
          message: 'Payment successful and subscription activated'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    // Check fresh status from PesaPal
    const environment = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox'
    const baseUrl = environment === 'live' 
      ? 'https://pay.pesapal.com/v3/api'
      : 'https://cybqa.pesapal.com/pesapalv3/api'

    // Get auth token
    const authResponse = await fetch(`${baseUrl}/Auth/RequestToken`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        consumer_key: Deno.env.get('PESAPAL_CONSUMER_KEY'),
        consumer_secret: Deno.env.get('PESAPAL_CONSUMER_SECRET')
      })
    })

    if (!authResponse.ok) {
      throw new Error('PesaPal authentication failed')
    }

    const authData = await authResponse.json()

    // Check transaction status
    const statusResponse = await fetch(
      `${baseUrl}/Transactions/GetTransactionStatus?orderTrackingId=${orderTrackingId}`,
      {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${authData.token}`
        }
      }
    )

    if (!statusResponse.ok) {
      throw new Error('PesaPal status check failed')
    }

    const statusData = await statusResponse.json()
    console.log('📊 Fresh payment status:', statusData)

    // If payment is completed, try to activate subscription
    if (statusData.payment_status_description === 'Completed' || statusData.status_code === 1) {
      try {
        // Use the robust subscription function
        const { data: subscriptionResult, error: subscriptionError } = await supabaseClient
          .rpc('extend_or_create_subscription_robust', {
            p_user_id: transaction.user_id,
            p_package_id: transaction.package_id,
            p_payment_reference: orderTrackingId,
            p_duration_days: transaction.package_duration_days || 30
          })

        if (subscriptionError || !subscriptionResult.success) {
          console.error('❌ Subscription creation failed:', subscriptionError || subscriptionResult.error)
          
          return new Response(
            JSON.stringify({ 
              success: true,
              status: 'payment_success_db_error',
              message: 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.',
              payment_successful: true,
              subscription_pending: true
            }),
            { 
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 200 
            }
          )
        }

        // Update transaction as completed
        await supabaseClient
          .from('pesapal_transactions')
          .update({
            status: 'completed',
            payment_status_description: statusData.payment_status_description,
            payment_method: statusData.payment_method,
            pesapal_response: statusData,
            updated_at: new Date().toISOString()
          })
          .eq('id', transaction.id)

        return new Response(
          JSON.stringify({ 
            success: true,
            status: 'completed',
            message: 'Payment successful and subscription activated',
            subscription_result: subscriptionResult
          }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200 
          }
        )

      } catch (error) {
        console.error('💥 Subscription activation error:', error)
        
        return new Response(
          JSON.stringify({ 
            success: true,
            status: 'payment_success_db_error',
            message: 'Your payment went through, but we\'re verifying your subscription. Please refresh or contact support.',
            payment_successful: true,
            subscription_pending: true
          }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200 
          }
        )
      }
    } else if (statusData.payment_status_description === 'Failed' || statusData.status_code === 2) {
      // Update transaction as failed
      await supabaseClient
        .from('pesapal_transactions')
        .update({
          status: 'failed',
          payment_status_description: statusData.payment_status_description,
          pesapal_response: statusData,
          updated_at: new Date().toISOString()
        })
        .eq('id', transaction.id)

      return new Response(
        JSON.stringify({ 
          success: false,
          status: 'failed',
          message: statusData.payment_status_description || 'Payment failed'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    } else {
      // Still pending
      return new Response(
        JSON.stringify({ 
          success: false,
          status: 'pending',
          message: 'Payment is still being processed'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

  } catch (error) {
    console.error('💥 Payment status check error:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false,
        status: 'error',
        message: 'Error checking payment status'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})
