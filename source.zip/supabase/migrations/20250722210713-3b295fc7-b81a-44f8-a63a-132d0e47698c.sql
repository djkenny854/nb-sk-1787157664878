
-- Fix RLS policies for payment processing and user access

-- Update tickets table policies to allow subscribed users to view tickets
DROP POLICY IF EXISTS "Users can view tickets for subscribed packages" ON public.tickets;
CREATE POLICY "Users can view tickets for subscribed packages" 
  ON public.tickets 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.user_subscriptions us 
      WHERE us.user_id = auth.uid() 
        AND us.package_id = tickets.package_id 
        AND us.is_active = true 
        AND us.end_date > NOW()
    )
  );

-- Ensure service role can manage user_subscriptions for payment processing
CREATE POLICY "Service role can manage subscriptions" 
  ON public.user_subscriptions 
  FOR ALL 
  USING (auth.role() = 'service_role');

-- Allow service role to manage pesapal_transactions
CREATE POLICY "Service role can manage transactions" 
  ON public.pesapal_transactions 
  FOR ALL 
  USING (auth.role() = 'service_role');

-- Allow service role to manage notifications
CREATE POLICY "Service role can manage notifications" 
  ON public.notifications 
  FOR ALL 
  USING (auth.role() = 'service_role');

-- Update extend_or_create_subscription function to be more permissive for service calls
CREATE OR REPLACE FUNCTION extend_or_create_subscription(
  p_user_id UUID,
  p_package_id UUID,
  p_payment_reference TEXT,
  p_duration_days INTEGER
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_subscription_id UUID;
  new_end_date TIMESTAMP WITH TIME ZONE;
  subscription_id UUID;
BEGIN
  -- Check for existing active subscription for this package
  SELECT id INTO existing_subscription_id
  FROM user_subscriptions
  WHERE user_id = p_user_id 
    AND package_id = p_package_id 
    AND is_active = true 
    AND end_date > NOW();

  IF existing_subscription_id IS NOT NULL THEN
    -- Extend existing subscription
    SELECT end_date INTO new_end_date
    FROM user_subscriptions
    WHERE id = existing_subscription_id;
    
    -- Add duration to existing end date
    new_end_date := new_end_date + (p_duration_days || ' days')::INTERVAL;
    
    UPDATE user_subscriptions
    SET 
      end_date = new_end_date,
      updated_at = NOW(),
      payment_reference = p_payment_reference
    WHERE id = existing_subscription_id;
    
    -- Create notification for extension
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Subscription Extended! 🎉',
      'Your subscription has been extended by ' || p_duration_days || ' days. New expiry: ' || new_end_date::DATE,
      'success'
    );
    
    RETURN existing_subscription_id;
  ELSE
    -- Create new subscription
    INSERT INTO user_subscriptions (
      user_id,
      package_id,
      start_date,
      end_date,
      payment_reference,
      is_active
    ) VALUES (
      p_user_id,
      p_package_id,
      NOW(),
      NOW() + (p_duration_days || ' days')::INTERVAL,
      p_payment_reference,
      true
    ) RETURNING id INTO subscription_id;
    
    -- Create welcome notification
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (
      p_user_id,
      'Welcome to Premium! 🌟',
      'Your subscription is now active for ' || p_duration_days || ' days. Enjoy premium tips!',
      'success'
    );
    
    RETURN subscription_id;
  END IF;
END;
$$;

-- Create function to check if user has active subscription for any package
CREATE OR REPLACE FUNCTION user_has_active_subscription(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_subscriptions 
    WHERE user_id = p_user_id 
      AND is_active = true 
      AND end_date > NOW()
  );
END;
$$;

-- Update RLS policies for better payment webhook access
-- Ensure payment webhooks can update transaction status
CREATE POLICY "Webhooks can update transaction status" 
  ON public.pesapal_transactions 
  FOR UPDATE 
  USING (true);

-- Allow authenticated users to view their transaction history
CREATE POLICY "Users can view own transaction history" 
  ON public.pesapal_transactions 
  FOR SELECT 
  USING (auth.uid() = user_id);
